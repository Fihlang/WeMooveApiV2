import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}
  
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const isAuthenticated = this.authService.isAuthenticated;
    
    if (isAuthenticated) {
      // User is authenticated, allow access
      return true;
    }
    
    // User is not authenticated, redirect to login
    this.router.navigate(['/auth/login'], { 
      queryParams: { returnUrl: state.url }
    });
    
    return false;
  }
}